/**
 * @file types.ts
 * @description Shared domain types for the SchoolDiary parent assistant.
 *              Every module imports from here so the data shape stays in one place.
 */

/** A family (one parent account, one child) the assistant serves. Multi-user ready. */
export interface Family {
  /** Stable slug, e.g. "praveen". Used as the key in the state store. */
  readonly id: string;
  /** Child's first name, used only in message greetings. */
  readonly childName: string;
  /** Class / grade as the school writes it, e.g. "3". Drives question difficulty. */
  readonly grade: string;
  readonly schoolDiary: {
    readonly username: string;
    readonly password: string;
  };
  /** Telegram chat IDs that receive this family's messages (parent, spouse, family group). */
  readonly telegramChatIds: readonly string[];
  /** Google Calendar ID to write events into. Omit to disable calendar sync. */
  readonly calendarId?: string;
}

/** A file attached to a SchoolDiary post (homework PDF, worksheet photo). */
export interface Attachment {
  readonly url: string;
  readonly fileName: string;
  /** Filled in after download. */
  readonly mediaType?: SupportedMediaType;
  readonly base64?: string;
}

export type SupportedMediaType =
  | "application/pdf"
  | "image/jpeg"
  | "image/png"
  | "image/gif"
  | "image/webp";

/** A post as fetched from SchoolDiary, normalised to one shape regardless of the portal's JSON. */
export interface RawPost {
  readonly id: string;
  readonly title: string;
  readonly body: string;
  /** ISO-8601 timestamp of when the school posted it. */
  readonly postedAt: string;
  readonly attachments: readonly Attachment[];
}

/** What Claude decided a post is. */
export type ItemKind =
  | "homework"
  | "classwork"
  | "event"
  | "notice"
  | "fee"
  | "exam"
  | "holiday"
  | "other";

/** Structured result of reading one post. */
export interface ExtractedItem {
  readonly postId: string;
  readonly kind: ItemKind;
  readonly subject: string | null;
  /** One-line summary written for a busy parent. */
  readonly summary: string;
  /** YYYY-MM-DD when homework / fee / submission is due. */
  readonly dueDate: string | null;
  /** YYYY-MM-DD of the event, exam or holiday. */
  readonly eventDate: string | null;
  /** HH:MM 24h local time, if stated. */
  readonly eventTime: string | null;
  readonly location: string | null;
  readonly dressCode: string | null;
  /** Things to buy, carry or send (chart paper, fee, costume). */
  readonly itemsNeeded: readonly string[];
  /** What the parent personally must do (sign, pay, attend). */
  readonly parentAction: string | null;
  /** Topics taught or assigned, used for practice questions. */
  readonly topics: readonly string[];
  readonly postedAt: string;
}

/** One practice question for the child. */
export interface PracticeQuestion {
  readonly subject: string;
  readonly question: string;
  readonly answer: string;
}

/** Per-family persisted state. */
export interface FamilyState {
  readonly seenPostIds: readonly string[];
  readonly items: readonly ExtractedItem[];
  readonly calendarEventIds: readonly string[];
  readonly lastRunAt: string | null;
}
