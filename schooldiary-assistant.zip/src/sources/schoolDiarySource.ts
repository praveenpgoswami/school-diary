/**
 * @file schoolDiarySource.ts
 * @description Logs in to the SchoolDiary parent web portal with Playwright (headless
 *              Chromium) and captures the JSON the portal's own pages load. Using the
 *              portal's JSON instead of scraping HTML keeps this stable across UI tweaks.
 *              Also downloads attachments with the same logged-in session.
 */

import { chromium, type Browser, type BrowserContext, type LaunchOptions, type Page, type Response } from "playwright";
import type { PortalConfig } from "../config.js";
import type { Attachment, RawPost, SupportedMediaType } from "../types.js";
import { normalizePosts } from "./normalize.js";
import { errorMessage, log } from "../util/log.js";

/** Thrown when the portal rejects the credentials or the login form cannot be found. */
export class LoginError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "LoginError";
  }
}

/** One JSON response captured from the portal. */
export interface CapturedResponse {
  readonly url: string;
  readonly status: number;
  readonly body: unknown;
}

const MEDIA_BY_EXTENSION: Readonly<Record<string, SupportedMediaType>> = {
  pdf: "application/pdf",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  gif: "image/gif",
  webp: "image/webp",
};

const MEDIA_BY_CONTENT_TYPE: Readonly<Record<string, SupportedMediaType>> = {
  "application/pdf": "application/pdf",
  "image/jpeg": "image/jpeg",
  "image/jpg": "image/jpeg",
  "image/png": "image/png",
  "image/gif": "image/gif",
  "image/webp": "image/webp",
};

/** Resolves a supported media type from the response header first, then the file extension. */
export function resolveMediaType(contentType: string | undefined, fileName: string): SupportedMediaType | undefined {
  const header = (contentType ?? "").split(";")[0]?.trim().toLowerCase() ?? "";
  const fromHeader = MEDIA_BY_CONTENT_TYPE[header];
  if (fromHeader !== undefined) {
    return fromHeader;
  }
  const ext = fileName.split("?")[0]?.split(".").pop()?.toLowerCase() ?? "";
  return MEDIA_BY_EXTENSION[ext];
}

/** One network response, recorded for discovery (no body). */
export interface NetworkEntry {
  readonly url: string;
  readonly method: string;
  readonly status: number;
  readonly resourceType: string;
  readonly contentType: string;
}

/** What the browser is showing right now, for discovery. */
export interface PageSnapshot {
  readonly url: string;
  readonly title: string;
  readonly html: string;
  readonly links: readonly { readonly text: string; readonly href: string }[];
}

const API_RESOURCE_TYPES: ReadonlySet<string> = new Set(["xhr", "fetch"]);

const LOGIN_TIMEOUT_MS = 30_000;
const PAGE_TIMEOUT_MS = 45_000;

/** A logged-in browser session. Always call `close()` (use try/finally). */
export class SchoolDiarySession {
  private readonly captured: CapturedResponse[] = [];
  private readonly network: NetworkEntry[] = [];
  private readonly pending: Promise<void>[] = [];

  private constructor(
    private readonly browser: Browser,
    private readonly context: BrowserContext,
    private readonly page: Page,
    private readonly portal: PortalConfig,
  ) {
    page.on("response", (response) => {
      this.pending.push(this.capture(response));
    });
  }

  /**
   * Launches Chromium and logs in.
   * @throws LoginError if the form is missing or credentials are rejected.
   */
  static async open(portal: PortalConfig, credentials: { readonly username: string; readonly password: string }): Promise<SchoolDiarySession> {
    const launchOptions: LaunchOptions = { headless: portal.headless };
    if (portal.executablePath !== undefined) {
      launchOptions.executablePath = portal.executablePath;
    }
    const browser = await chromium.launch(launchOptions);
    try {
      const context = await browser.newContext({ locale: "en-IN", timezoneId: "Asia/Kolkata" });
      const page = await context.newPage();
      page.setDefaultTimeout(PAGE_TIMEOUT_MS);
      const session = new SchoolDiarySession(browser, context, page, portal);
      await session.login(credentials);
      return session;
    } catch (err) {
      await browser.close();
      throw err;
    }
  }

  /**
   * Records every response in the network log, and parses the body as JSON when it is
   * JSON-typed OR an XHR/fetch call (some portals send JSON as text/html or text/plain).
   */
  private async capture(response: Response): Promise<void> {
    const contentType = response.headers()["content-type"] ?? "";
    const resourceType = response.request().resourceType();
    this.network.push({ url: response.url(), method: response.request().method(), status: response.status(), resourceType, contentType });
    const isJsonTyped = contentType.includes("json");
    const isApiCall = API_RESOURCE_TYPES.has(resourceType);
    if (!isJsonTyped && !isApiCall) {
      return;
    }
    try {
      const text = (await response.text()).trim();
      if (!text.startsWith("{") && !text.startsWith("[")) {
        return;
      }
      const body: unknown = JSON.parse(text);
      this.captured.push({ url: response.url(), status: response.status(), body });
    } catch {
      // Body unavailable (redirect, aborted request); nothing to capture.
    }
  }

  private async login(credentials: { readonly username: string; readonly password: string }): Promise<void> {
    await this.page.goto(this.portal.loginUrl, { waitUntil: "domcontentloaded" });
    const user = this.page.locator(this.portal.usernameSelector).first();
    const pass = this.page.locator(this.portal.passwordSelector).first();
    try {
      await user.waitFor({ state: "visible", timeout: LOGIN_TIMEOUT_MS });
    } catch {
      throw new LoginError("Login form not found. Check SD_LOGIN_URL and SD_USERNAME_SELECTOR (run `npm run discover`).");
    }
    await user.fill(credentials.username);
    await pass.fill(credentials.password);
    await this.page.locator(this.portal.submitSelector).first().click();
    await this.settle();
    const stillOnLogin = await pass.isVisible().catch(() => false);
    if (stillOnLogin) {
      throw new LoginError("Still on the login page after submitting. Check the username/password or SD_SUBMIT_SELECTOR.");
    }
    log.info("Logged in to SchoolDiary");
  }

  /** Waits for network quiet, but never fails the run if the portal keeps a socket open. */
  private async settle(): Promise<void> {
    try {
      await this.page.waitForLoadState("networkidle", { timeout: 20_000 });
    } catch {
      await this.page.waitForTimeout(3_000);
    }
  }

  /** Scrolls a few times so infinite-scroll feeds load older items. */
  private async scrollFeed(times = 4): Promise<void> {
    for (let i = 0; i < times; i += 1) {
      await this.page.mouse.wheel(0, 4_000);
      await this.page.waitForTimeout(1_200);
    }
  }

  /** Opens the configured feed pages (or stays on the landing page) and lets them load. */
  async loadFeedPages(): Promise<void> {
    const urls = this.portal.feedPageUrls;
    if (urls.length === 0) {
      await this.scrollFeed();
      await this.settle();
      return;
    }
    for (const url of urls) {
      try {
        await this.page.goto(url, { waitUntil: "domcontentloaded" });
        await this.settle();
        await this.scrollFeed();
      } catch (err) {
        log.warn("Feed page failed to load", { url, error: errorMessage(err) });
      }
    }
  }

  /** All JSON captured so far (used by discovery mode). */
  async allCaptured(): Promise<CapturedResponse[]> {
    await Promise.allSettled(this.pending);
    return [...this.captured];
  }

  /** Posts found in JSON responses whose URL matches SD_FEED_API_PATTERN. */
  async posts(): Promise<RawPost[]> {
    const all = await this.allCaptured();
    const matching = all.filter((c) => c.status < 400 && this.portal.feedApiPattern.test(c.url));
    return normalizePosts(matching.map((c) => c.body), this.portal.fieldMap);
  }

  /** Every response seen so far, without bodies (discovery only). */
  async networkLog(): Promise<NetworkEntry[]> {
    await Promise.allSettled(this.pending);
    return [...this.network];
  }

  /** Current URL, title, HTML and all links/menu items on the page (discovery only). */
  async snapshot(): Promise<PageSnapshot> {
    const links = await this.page.$$eval("a[href]", (anchors) =>
      anchors.map((a) => ({ text: (a.textContent ?? "").trim().slice(0, 80), href: (a as HTMLAnchorElement).href })),
    );
    return { url: this.page.url(), title: await this.page.title(), html: await this.page.content(), links };
  }

  /** Saves a screenshot of the current page (discovery/debugging only). */
  async screenshot(path: string): Promise<void> {
    await this.page.screenshot({ path, fullPage: true });
  }

  /**
   * Downloads an attachment with the logged-in cookies.
   * @returns The attachment with base64 + media type, or undefined if unsupported/too large/failed.
   */
  async download(attachment: Attachment, maxBytes: number): Promise<Attachment | undefined> {
    try {
      const response = await this.context.request.get(attachment.url, { timeout: PAGE_TIMEOUT_MS });
      if (!response.ok()) {
        log.warn("Attachment download failed", { file: attachment.fileName, status: response.status() });
        return undefined;
      }
      const mediaType = resolveMediaType(response.headers()["content-type"], attachment.fileName);
      if (mediaType === undefined) {
        log.info("Skipping unsupported attachment type", { file: attachment.fileName });
        return undefined;
      }
      const buffer = await response.body();
      if (buffer.byteLength > maxBytes) {
        log.warn("Attachment too large, skipping", { file: attachment.fileName, bytes: buffer.byteLength });
        return undefined;
      }
      return { ...attachment, mediaType, base64: buffer.toString("base64") };
    } catch (err) {
      log.warn("Attachment download error", { file: attachment.fileName, error: errorMessage(err) });
      return undefined;
    }
  }

  async close(): Promise<void> {
    await this.browser.close();
  }
}
