/**
 * @file normalize.ts
 * @description Turns whatever JSON the SchoolDiary portal returns into RawPost objects.
 *              The portal has no public API contract, so instead of hard-coding one
 *              response shape this walks every captured JSON body, finds objects that
 *              look like posts, and maps their fields using candidate key lists.
 *              Override the candidates with SD_FIELD_MAP once you know the real keys.
 *              Pure functions only, so it is fully unit-tested.
 */

import type { Attachment, RawPost } from "../types.js";
import type { FieldName } from "../config.js";

/** Default key candidates, checked in order, case-insensitively. Dotted paths allowed. */
export const DEFAULT_FIELD_CANDIDATES: Readonly<Record<FieldName, readonly string[]>> = {
  id: ["id", "_id", "postId", "post_id", "messageId", "message_id", "feedId", "uuid"],
  title: ["title", "subject", "heading", "name", "topic"],
  body: ["body", "message", "description", "content", "text", "details", "msg"],
  postedAt: ["postedAt", "createdAt", "created_at", "date", "createdOn", "created_on", "timestamp", "publishDate", "sentAt"],
  attachments: ["attachments", "files", "media", "documents", "images", "attachment"],
  attachmentUrl: ["url", "fileUrl", "file_url", "link", "path", "src", "downloadUrl"],
  attachmentName: ["name", "fileName", "file_name", "title", "originalName"],
};

type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
type JsonObject = { [key: string]: Json };

function isObject(value: unknown): value is JsonObject {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Reads a value by key or dotted path, matching keys case-insensitively. */
export function readPath(obj: JsonObject, path: string): Json | undefined {
  let current: Json | undefined = obj;
  for (const segment of path.split(".")) {
    if (!isObject(current)) {
      return undefined;
    }
    const lower = segment.toLowerCase();
    const key: string | undefined = Object.keys(current).find((k) => k.toLowerCase() === lower);
    if (key === undefined) {
      return undefined;
    }
    current = current[key];
  }
  return current;
}

function firstPresent(obj: JsonObject, candidates: readonly string[]): Json | undefined {
  for (const c of candidates) {
    const v = readPath(obj, c);
    if (v !== undefined && v !== null && v !== "") {
      return v;
    }
  }
  return undefined;
}

function asText(value: Json | undefined): string {
  const converters: Record<string, (v: Json) => string> = {
    string: (v) => String(v),
    number: (v) => String(v),
    boolean: (v) => String(v),
  };
  if (value === undefined || value === null) {
    return "";
  }
  const convert = converters[typeof value];
  if (convert === undefined) {
    return "";
  }
  return convert(value);
}

/** Strips HTML tags and decodes the handful of entities school portals typically emit. */
export function stripHtml(input: string): string {
  const entities: Record<string, string> = { "&nbsp;": " ", "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#39;": "'" };
  return input
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|li)>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&(nbsp|amp|lt|gt|quot|#39);/g, (m) => entities[m] ?? m)
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** Converts epoch seconds, epoch ms or a date string to ISO-8601. Returns null if unparseable. */
export function toIsoTimestamp(value: Json | undefined): string | null {
  if (typeof value === "number") {
    let ms = value;
    if (value < 1e12) {
      ms = value * 1000;
    }
    const d = new Date(ms);
    if (Number.isNaN(d.getTime())) {
      return null;
    }
    return d.toISOString();
  }
  if (typeof value === "string" && value.trim() !== "") {
    if (/^\d{10,13}$/.test(value.trim())) {
      return toIsoTimestamp(Number(value.trim()));
    }
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) {
      return null;
    }
    return d.toISOString();
  }
  return null;
}

const FILE_URL = /https?:\/\/[^\s"'<>]+?\.(pdf|jpe?g|png|gif|webp)(\?[^\s"'<>]*)?/gi;

function fileNameFromUrl(url: string): string {
  const clean = url.split("?")[0] ?? url;
  const last = clean.split("/").pop();
  return decodeURIComponent(last ?? "attachment");
}

function extractAttachments(obj: JsonObject, candidates: Readonly<Record<FieldName, readonly string[]>>, bodyText: string): Attachment[] {
  const found = new Map<string, Attachment>();
  const add = (url: string, name?: string): void => {
    if (!/^https?:\/\//i.test(url) || found.has(url)) {
      return;
    }
    found.set(url, { url, fileName: name ?? fileNameFromUrl(url) });
  };
  const raw = firstPresent(obj, candidates.attachments);
  const list: Json[] = [];
  if (Array.isArray(raw)) {
    list.push(...raw);
  } else if (raw !== undefined) {
    list.push(raw);
  }
  for (const entry of list) {
    if (typeof entry === "string") {
      add(entry);
    } else if (isObject(entry)) {
      const url = asText(firstPresent(entry, candidates.attachmentUrl));
      const name = asText(firstPresent(entry, candidates.attachmentName));
      if (url !== "") {
        add(url, name || undefined);
      }
    }
  }
  for (const match of bodyText.matchAll(FILE_URL)) {
    add(match[0]);
  }
  return [...found.values()];
}

function mergeCandidates(fieldMap: Partial<Record<FieldName, readonly string[]>>): Record<FieldName, readonly string[]> {
  const merged = { ...DEFAULT_FIELD_CANDIDATES } as Record<FieldName, readonly string[]>;
  for (const [key, list] of Object.entries(fieldMap) as [FieldName, readonly string[] | undefined][]) {
    if (list !== undefined && list.length > 0) {
      merged[key] = [...list, ...DEFAULT_FIELD_CANDIDATES[key]];
    }
  }
  return merged;
}

/**
 * Maps one object to a post. An object qualifies only if it has an id AND either a body,
 * or a title plus a parseable date. This rejects look-alikes such as
 * `author: { id, name }` or attachment records `{ id, name, url }`.
 */
function toPost(obj: JsonObject, candidates: Readonly<Record<FieldName, readonly string[]>>, fallbackTime: string): RawPost | null {
  const id = asText(firstPresent(obj, candidates.id));
  const title = stripHtml(asText(firstPresent(obj, candidates.title)));
  const rawBody = asText(firstPresent(obj, candidates.body));
  const body = stripHtml(rawBody);
  const postedAt = toIsoTimestamp(firstPresent(obj, candidates.postedAt));
  const hasContent = body !== "" || (title !== "" && postedAt !== null);
  if (id === "" || !hasContent) {
    return null;
  }
  return {
    id,
    title,
    body,
    postedAt: postedAt ?? fallbackTime,
    attachments: extractAttachments(obj, candidates, rawBody),
  };
}

/**
 * Depth-first collection. Children are searched first; an object is treated as a post
 * only if none of its descendants were, so API wrappers like `{ id, message: "OK", data: [...] }`
 * are never mistaken for posts. Attachment sub-trees are skipped.
 * @returns Number of posts found in this sub-tree.
 */
function collect(node: Json, attachmentKeys: ReadonlySet<string>, onPost: (obj: JsonObject) => boolean): number {
  if (Array.isArray(node)) {
    return node.reduce<number>((sum, child) => sum + collect(child, attachmentKeys, onPost), 0);
  }
  if (!isObject(node)) {
    return 0;
  }
  let found = 0;
  for (const [key, child] of Object.entries(node)) {
    if (!attachmentKeys.has(key.toLowerCase())) {
      found += collect(child, attachmentKeys, onPost);
    }
  }
  if (found > 0) {
    return found;
  }
  if (onPost(node)) {
    return 1;
  }
  return 0;
}

/**
 * Finds post-like objects anywhere inside the captured JSON bodies.
 * @param bodies - Parsed JSON responses captured from the portal.
 * @param fieldMap - Optional key overrides from SD_FIELD_MAP.
 * @param now - Fallback timestamp for posts without a parseable date.
 * @returns Unique posts, newest first.
 */
export function normalizePosts(
  bodies: readonly unknown[],
  fieldMap: Partial<Record<FieldName, readonly string[]>> = {},
  now: Date = new Date(),
): RawPost[] {
  const candidates = mergeCandidates(fieldMap);
  const fallback = now.toISOString();
  const attachmentKeys = new Set(candidates.attachments.map((k) => k.toLowerCase()));
  const byId = new Map<string, RawPost>();
  for (const body of bodies) {
    collect(body as Json, attachmentKeys, (obj) => {
      const post = toPost(obj, candidates, fallback);
      if (post === null) {
        return false;
      }
      if (!byId.has(post.id)) {
        byId.set(post.id, post);
      }
      return true;
    });
  }
  return [...byId.values()].sort((a, b) => b.postedAt.localeCompare(a.postedAt));
}
