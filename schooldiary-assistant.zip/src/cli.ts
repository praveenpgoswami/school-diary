/**
 * @file cli.ts
 * @description Command-line entry point.
 *   evening        Fetch new posts, read them with Claude, send the evening digest.
 *   morning        Send today's checklist from saved state (no login, no AI).
 *   discover       Log in and dump the portal's JSON responses for setup.
 *   telegram-chats List chat IDs that messaged your bot (setup helper; needs only the bot token).
 */

import { ConfigError, loadConfig, loadDotEnv, type AppConfig } from "./config.js";
import { TelegramClient } from "./delivery/telegram.js";
import { runDiscover } from "./jobs/discover.js";
import { runEvening } from "./jobs/evening.js";
import { runMorning } from "./jobs/morning.js";
import { errorMessage, log, registerSecret } from "./util/log.js";

/** A command either needs the full config or runs standalone from env. */
type Command =
  | { readonly kind: "configured"; readonly needs: { readonly ai: boolean; readonly telegram: boolean }; readonly run: (config: AppConfig) => Promise<number> }
  | { readonly kind: "standalone"; readonly run: () => Promise<number> };

async function listTelegramChats(): Promise<number> {
  const token = process.env["TELEGRAM_BOT_TOKEN"]?.trim();
  if (token === undefined || token === "") {
    throw new ConfigError("Missing required environment variable TELEGRAM_BOT_TOKEN. See .env.example.");
  }
  registerSecret(token);
  const chats = await new TelegramClient(token).recentChats();
  if (chats.length === 0) {
    console.log("No chats yet. Send any message to your bot in Telegram, then run this again.");
    return 1;
  }
  console.table(chats);
  return 0;
}

const COMMANDS: Readonly<Record<string, Command>> = {
  evening: { kind: "configured", needs: { ai: true, telegram: true }, run: runEvening },
  morning: { kind: "configured", needs: { ai: false, telegram: true }, run: runMorning },
  discover: { kind: "configured", needs: { ai: false, telegram: false }, run: runDiscover },
  "telegram-chats": { kind: "standalone", run: listTelegramChats },
};

async function runConfigured(command: Extract<Command, { kind: "configured" }>): Promise<number> {
  const config = loadConfig(process.env, command.needs);
  registerSecret(config.anthropicApiKey);
  registerSecret(config.telegramBotToken);
  registerSecret(config.googleServiceAccountJson);
  for (const family of config.families) {
    registerSecret(family.schoolDiary.password);
  }
  return command.run(config);
}

const RUNNERS: { readonly [K in Command["kind"]]: (command: Extract<Command, { kind: K }>) => Promise<number> } = {
  configured: runConfigured,
  standalone: (command) => command.run(),
};

async function main(): Promise<void> {
  loadDotEnv();
  const name = process.argv[2] ?? "";
  const command = COMMANDS[name];
  if (command === undefined) {
    console.error(`Usage: node dist/src/cli.js <${Object.keys(COMMANDS).join("|")}>`);
    process.exitCode = 2;
    return;
  }
  const runner = RUNNERS[command.kind] as (c: Command) => Promise<number>;
  const failures = await runner(command);
  if (failures > 0) {
    process.exitCode = 1;
  }
}

main().catch((err: unknown) => {
  log.error("Fatal error", { error: errorMessage(err) });
  process.exitCode = 1;
});
