/**
 * @file morning.ts
 * @description Morning job. Needs no login and no AI call: it reads the items saved by
 *              last night's run and sends today's bag/uniform/to-do checklist.
 */

import type { AppConfig } from "../config.js";
import { buildMorningChecklist } from "../digest/buildDigest.js";
import { TelegramClient } from "../delivery/telegram.js";
import { familyState, loadState } from "../store/stateStore.js";
import { istDate } from "../util/dates.js";
import { log } from "../util/log.js";

/** Sends the morning checklist to every family. Returns the number of families with no successful delivery. */
export async function runMorning(config: AppConfig): Promise<number> {
  const telegram = new TelegramClient(config.telegramBotToken, config.telegramApiBase);
  const state = await loadState(config.stateFile);
  const today = istDate();
  let failures = 0;
  for (const family of config.families) {
    const { items } = familyState(state, family.id);
    const message = buildMorningChecklist({ childName: family.childName, today, allItems: items });
    const delivered = await telegram.broadcast(family.telegramChatIds, message);
    if (delivered === 0) {
      failures += 1;
    }
    log.info("Morning checklist sent", { family: family.id, delivered });
  }
  return failures;
}
