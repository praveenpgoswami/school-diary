/**
 * @file evening.ts
 * @description The main daily job. For each family: log in, fetch new posts, read them
 *              (with attachments) via Claude, generate practice questions, add calendar
 *              events, send the evening digest, and save state. One family failing never
 *              stops the others, and the parent gets a Telegram alert instead of silence.
 */

import type { AppConfig } from "../config.js";
import type { ExtractedItem, Family, FamilyState, RawPost } from "../types.js";
import { ClaudeClient } from "../ai/claudeClient.js";
import { extractItem } from "../ai/extract.js";
import { generateQuestions } from "../ai/practiceQuestions.js";
import { buildEveningDigest } from "../digest/buildDigest.js";
import { CalendarClient, buildEvent, calendarDateFor, eventIdFor } from "../delivery/calendar.js";
import { TelegramClient } from "../delivery/telegram.js";
import { SchoolDiarySession } from "../sources/schoolDiarySource.js";
import { familyState, loadState, mergeFamilyState, saveState, withFamilyState } from "../store/stateStore.js";
import { addDays, istDate } from "../util/dates.js";
import { escapeHtml } from "../util/html.js";
import { errorMessage, log, redact } from "../util/log.js";

/**
 * Chooses which fetched posts to process. On the first run only recent posts are
 * processed; older ones are marked seen so you are not flooded with months of history.
 */
export function selectNewPosts(
  posts: readonly RawPost[],
  state: FamilyState,
  today: string,
  lookbackDays: number,
): { readonly toProcess: RawPost[]; readonly skippedAsOld: string[] } {
  const seen = new Set(state.seenPostIds);
  const unseen = posts.filter((p) => !seen.has(p.id));
  if (state.lastRunAt !== null) {
    return { toProcess: unseen, skippedAsOld: [] };
  }
  const cutoff = addDays(today, -lookbackDays);
  const toProcess = unseen.filter((p) => istDate(new Date(p.postedAt)) >= cutoff);
  const skippedAsOld = unseen.filter((p) => istDate(new Date(p.postedAt)) < cutoff).map((p) => p.id);
  return { toProcess, skippedAsOld };
}

async function readPosts(
  session: SchoolDiarySession,
  claude: ClaudeClient,
  posts: readonly RawPost[],
  family: Family,
  maxAttachmentBytes: number,
): Promise<{ items: ExtractedItem[]; processedIds: string[] }> {
  const items: ExtractedItem[] = [];
  const processedIds: string[] = [];
  for (const post of posts) {
    try {
      const attachments = [];
      for (const att of post.attachments) {
        const downloaded = await session.download(att, maxAttachmentBytes);
        if (downloaded !== undefined) {
          attachments.push(downloaded);
        }
      }
      const item = await extractItem(claude, { ...post, attachments }, family.grade);
      items.push(item);
      processedIds.push(post.id);
    } catch (err) {
      // Not marked as seen, so it is retried on the next run.
      log.error("Failed to read post; will retry next run", { family: family.id, postId: post.id, error: errorMessage(err) });
    }
  }
  return { items, processedIds };
}

async function syncCalendar(
  calendar: CalendarClient | undefined,
  family: Family,
  items: readonly ExtractedItem[],
  alreadyCreated: readonly string[],
): Promise<string[]> {
  const calendarId = family.calendarId;
  if (calendar === undefined || calendarId === undefined) {
    return [];
  }
  const done = new Set(alreadyCreated);
  const created: string[] = [];
  for (const item of items) {
    const date = calendarDateFor(item);
    const id = eventIdFor(family.id, item.postId);
    if (date === null || done.has(id)) {
      continue;
    }
    try {
      created.push(await calendar.upsert(calendarId, buildEvent(family.id, family.childName, item, date)));
    } catch (err) {
      log.error("Calendar event failed", { family: family.id, postId: item.postId, error: errorMessage(err) });
    }
  }
  return created;
}

/** Runs the evening job for all families. Returns the number of families that failed. */
export async function runEvening(config: AppConfig): Promise<number> {
  const claude = new ClaudeClient(config.anthropicApiKey, config.claudeModel);
  const telegram = new TelegramClient(config.telegramBotToken, config.telegramApiBase);
  let calendar: CalendarClient | undefined;
  if (config.googleServiceAccountJson !== undefined) {
    calendar = new CalendarClient(config.googleServiceAccountJson);
  }
  const today = istDate();
  let state = await loadState(config.stateFile);
  let failures = 0;

  for (const family of config.families) {
    const current = familyState(state, family.id);
    let session: SchoolDiarySession | undefined;
    try {
      session = await SchoolDiarySession.open(config.portal, family.schoolDiary);
      await session.loadFeedPages();
      const posts = await session.posts();
      const { toProcess, skippedAsOld } = selectNewPosts(posts, current, today, config.firstRunLookbackDays);
      log.info("Fetched posts", { family: family.id, total: posts.length, new: toProcess.length, skippedAsOld: skippedAsOld.length });

      const { items, processedIds } = await readPosts(session, claude, toProcess, family, config.maxAttachmentBytes);
      await session.close();
      session = undefined;

      const createdEvents = await syncCalendar(calendar, family, items, current.calendarEventIds);
      const next = mergeFamilyState(current, {
        newPostIds: [...processedIds, ...skippedAsOld],
        newItems: items,
        newCalendarEventIds: createdEvents,
        today,
        runAt: new Date().toISOString(),
      });

      let questions: Awaited<ReturnType<typeof generateQuestions>> = [];
      try {
        questions = await generateQuestions(claude, items, family.grade, config.questionsPerSubject);
      } catch (err) {
        log.warn("Practice questions failed; sending digest without them", { family: family.id, error: errorMessage(err) });
      }

      const digest = buildEveningDigest({ childName: family.childName, today, newItems: items, allItems: next.items, questions });
      await telegram.broadcast(family.telegramChatIds, digest);

      state = withFamilyState(state, family.id, next);
      await saveState(config.stateFile, state);
      log.info("Evening digest sent", { family: family.id, items: items.length, questions: questions.length, calendarEvents: createdEvents.length });
    } catch (err) {
      failures += 1;
      log.error("Evening run failed", { family: family.id, error: errorMessage(err) });
      await telegram.broadcast(
        family.telegramChatIds,
        `⚠️ Couldn't check SchoolDiary today: ${escapeHtml(redact(errorMessage(err)).slice(0, 300))}\nPlease open the app once today.`,
      );
    } finally {
      if (session !== undefined) {
        await session.close();
      }
    }
  }
  return failures;
}
