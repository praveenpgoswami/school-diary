/**
 * @file discover.ts
 * @description One-time setup helper. Logs in, opens the feed pages, and saves into
 *              data/discovery/ (git-ignored):
 *                responses.json  every JSON body the portal loaded
 *                summary.json    per JSON URL: posts detected, matched by SD_FEED_API_PATTERN
 *                network.json    every network request (no bodies): url, type, status, content-type
 *                links.json      every link/menu item on the final page
 *                page.html       the final page's HTML
 *                after-login.png full-page screenshot
 *              and prints a diagnosis of what to do next.
 *              Output contains your child's data: keep it local and remove names before sharing.
 */

import { mkdir, writeFile } from "node:fs/promises";
import type { AppConfig } from "../config.js";
import { normalizePosts } from "../sources/normalize.js";
import { SchoolDiarySession, type NetworkEntry } from "../sources/schoolDiarySource.js";
import { log } from "../util/log.js";

const OUT_DIR = "data/discovery";

type Diagnosis = "postsFound" | "jsonButNoPosts" | "apiCallsNoJson" | "serverRendered";

const ADVICE: Readonly<Record<Diagnosis, string>> = {
  postsFound: "Posts detected. Run `npm run evening`.",
  jsonButNoPosts:
    "JSON was captured but no posts were recognised. Check summary.json: if a URL has postsDetected > 0, set SD_FEED_API_PATTERN to match it; otherwise find the post list in responses.json and set SD_FIELD_MAP.",
  apiCallsNoJson:
    "The portal made API calls but none returned JSON. Open links.json, find the Messages/Homework/Notice pages, put their URLs in SD_FEED_PAGE_URLS (comma-separated) and run discover again.",
  serverRendered:
    "No API calls at all: the portal is probably server-rendered (posts are inside the HTML). Open links.json and after-login.png: if the feed is on another page, set SD_FEED_PAGE_URLS and run again. If posts are visible in page.html, an HTML parser is needed - share links.json and the network.json types with me.",
};

function diagnose(postsViaPattern: number, postsAnywhere: number, jsonCount: number, network: readonly NetworkEntry[]): Diagnosis {
  if (postsViaPattern > 0) {
    return "postsFound";
  }
  if (jsonCount > 0 || postsAnywhere > 0) {
    return "jsonButNoPosts";
  }
  const apiCalls = network.filter((n) => n.resourceType === "xhr" || n.resourceType === "fetch");
  if (apiCalls.length > 0) {
    return "apiCallsNoJson";
  }
  return "serverRendered";
}

function countBy(entries: readonly NetworkEntry[], key: (e: NetworkEntry) => string): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const e of entries) {
    const k = key(e);
    counts[k] = (counts[k] ?? 0) + 1;
  }
  return counts;
}

export async function runDiscover(config: AppConfig): Promise<number> {
  const family = config.families[0];
  if (family === undefined) {
    throw new Error("No family configured.");
  }
  await mkdir(OUT_DIR, { recursive: true });
  const session = await SchoolDiarySession.open(config.portal, family.schoolDiary);
  try {
    await session.loadFeedPages();
    await session.screenshot(`${OUT_DIR}/after-login.png`);
    const snap = await session.snapshot();
    const captured = await session.allCaptured();
    const network = await session.networkLog();

    const summary = captured.map((c) => ({
      url: c.url,
      status: c.status,
      postsDetected: normalizePosts([c.body], config.portal.fieldMap).length,
      matchedByPattern: config.portal.feedApiPattern.test(c.url),
    }));
    const posts = await session.posts();

    await Promise.all([
      writeFile(`${OUT_DIR}/responses.json`, JSON.stringify(captured, null, 2), "utf8"),
      writeFile(`${OUT_DIR}/summary.json`, JSON.stringify(summary, null, 2), "utf8"),
      writeFile(`${OUT_DIR}/posts.json`, JSON.stringify(posts, null, 2), "utf8"),
      writeFile(`${OUT_DIR}/network.json`, JSON.stringify(network, null, 2), "utf8"),
      writeFile(`${OUT_DIR}/links.json`, JSON.stringify(snap.links, null, 2), "utf8"),
      writeFile(`${OUT_DIR}/page.html`, snap.html, "utf8"),
    ]);

    const postsAnywhere = summary.reduce((sum, s) => sum + s.postsDetected, 0);
    const diagnosis = diagnose(posts.length, postsAnywhere, captured.length, network);

    console.log(`\nFinal page: ${snap.title} — ${snap.url}`);
    console.log("Network requests by type:", countBy(network, (n) => n.resourceType));
    if (summary.length > 0) {
      console.table(summary.map((s) => ({ posts: s.postsDetected, matched: s.matchedByPattern, status: s.status, url: s.url.slice(0, 90) })));
    }
    console.log(`Links on page: ${snap.links.length} (see links.json)`);
    log.info("Discovery complete", {
      jsonResponses: captured.length,
      networkRequests: network.length,
      postsViaPattern: posts.length,
      diagnosis,
      outDir: OUT_DIR,
    });
    console.log(`\nNext step: ${ADVICE[diagnosis]}\n`);
    return 0;
  } finally {
    await session.close();
  }
}
