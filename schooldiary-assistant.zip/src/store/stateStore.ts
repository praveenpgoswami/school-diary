/**
 * @file stateStore.ts
 * @description Persists what has been processed: seen post IDs, extracted items (needed
 *              for the morning checklist and "coming up" section) and created calendar
 *              events. Stored as one JSON file so it can be committed back by GitHub
 *              Actions; swap this module for a database when you go multi-user at scale.
 */

import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import type { ExtractedItem, FamilyState } from "../types.js";
import { addDays, isIsoDate } from "../util/dates.js";

export interface StateFile {
  readonly version: 1;
  readonly families: Readonly<Record<string, FamilyState>>;
}

const EMPTY_FAMILY: FamilyState = { seenPostIds: [], items: [], calendarEventIds: [], lastRunAt: null };
const MAX_SEEN_IDS = 3_000;
const ITEM_RETENTION_DAYS = 45;

/** Reads the state file; a missing file means a first run. */
export async function loadState(path: string): Promise<StateFile> {
  try {
    const raw = await readFile(path, "utf8");
    const parsed = JSON.parse(raw) as Partial<StateFile>;
    if (parsed.version !== 1 || typeof parsed.families !== "object" || parsed.families === null) {
      throw new Error(`State file ${path} has an unknown format.`);
    }
    return { version: 1, families: parsed.families };
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === "ENOENT") {
      return { version: 1, families: {} };
    }
    throw err;
  }
}

/** Writes atomically (temp file + rename) so a crash never leaves half a file. */
export async function saveState(path: string, state: StateFile): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  const tmp = `${path}.tmp`;
  await writeFile(tmp, `${JSON.stringify(state, null, 2)}\n`, "utf8");
  await rename(tmp, path);
}

export function familyState(state: StateFile, familyId: string): FamilyState {
  return state.families[familyId] ?? EMPTY_FAMILY;
}

export function withFamilyState(state: StateFile, familyId: string, next: FamilyState): StateFile {
  return { version: 1, families: { ...state.families, [familyId]: next } };
}

/** Latest relevant date for an item: the later of due date and event date. */
function lastRelevantDate(item: ExtractedItem): string {
  const dates = [item.dueDate, item.eventDate].filter(isIsoDate);
  if (dates.length === 0) {
    return item.postedAt.slice(0, 10);
  }
  return dates.sort().at(-1) ?? item.postedAt.slice(0, 10);
}

/**
 * Merges newly processed posts/items and prunes old data.
 * Items are kept while their due/event date is within the retention window.
 */
export function mergeFamilyState(
  current: FamilyState,
  update: {
    readonly newPostIds: readonly string[];
    readonly newItems: readonly ExtractedItem[];
    readonly newCalendarEventIds: readonly string[];
    readonly today: string;
    readonly runAt: string;
  },
): FamilyState {
  const seen = [...new Set([...current.seenPostIds, ...update.newPostIds])].slice(-MAX_SEEN_IDS);
  const cutoff = addDays(update.today, -ITEM_RETENTION_DAYS);
  const replacedIds = new Set(update.newItems.map((i) => i.postId));
  const items = [...current.items.filter((i) => !replacedIds.has(i.postId)), ...update.newItems]
    .filter((i) => lastRelevantDate(i) >= cutoff);
  const calendar = [...new Set([...current.calendarEventIds, ...update.newCalendarEventIds])].slice(-MAX_SEEN_IDS);
  return { seenPostIds: seen, items, calendarEventIds: calendar, lastRunAt: update.runAt };
}
