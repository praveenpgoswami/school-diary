/**
 * @file config.ts
 * @description Loads and validates all runtime configuration from environment variables.
 *              Secrets never live in code: locally they come from `.env`, on GitHub
 *              Actions from repository secrets. Supports one family (simple env vars)
 *              or many families (FAMILIES_JSON) so the code is product-ready.
 */

import { readFileSync, existsSync } from "node:fs";
import type { Family } from "./types.js";

/** Portal-specific settings. Filled in once you inspect the SchoolDiary web portal. */
export interface PortalConfig {
  readonly loginUrl: string;
  readonly usernameSelector: string;
  readonly passwordSelector: string;
  readonly submitSelector: string;
  /** Page(s) to open after login that load the feed / homework / notices. */
  readonly feedPageUrls: readonly string[];
  /** Regex matched against response URLs; matching JSON responses are treated as feed data. */
  readonly feedApiPattern: RegExp;
  /** Optional override of which JSON keys hold id/title/body/date/attachments. */
  readonly fieldMap: Partial<Record<FieldName, readonly string[]>>;
  readonly headless: boolean;
  /** Use an already-installed Chrome/Chromium instead of Playwright's download. */
  readonly executablePath: string | undefined;
}

export type FieldName = "id" | "title" | "body" | "postedAt" | "attachments" | "attachmentUrl" | "attachmentName";

export interface AppConfig {
  readonly anthropicApiKey: string;
  readonly claudeModel: string;
  readonly telegramBotToken: string;
  /** Telegram API base URL; only overridden in tests. */
  readonly telegramApiBase: string;
  /** Raw service-account JSON for Google Calendar. Undefined disables calendar sync. */
  readonly googleServiceAccountJson: string | undefined;
  readonly stateFile: string;
  /** How many days back to look on the very first run. */
  readonly firstRunLookbackDays: number;
  /** Max attachment size sent to Claude, in bytes. */
  readonly maxAttachmentBytes: number;
  readonly questionsPerSubject: number;
  readonly portal: PortalConfig;
  readonly families: readonly Family[];
}

/** Error thrown for missing or malformed configuration. Message names the variable, never its value. */
export class ConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ConfigError";
  }
}

/**
 * Minimal `.env` loader (KEY=value lines, # comments). Existing env vars win,
 * so GitHub Actions secrets are never overridden by a stray local file.
 */
export function loadDotEnv(path = ".env"): void {
  if (!existsSync(path)) {
    return;
  }
  const lines = readFileSync(path, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed === "" || trimmed.startsWith("#")) {
      continue;
    }
    const eq = trimmed.indexOf("=");
    if (eq <= 0) {
      continue;
    }
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim().replace(/^["']|["']$/g, "");
    if (process.env[key] === undefined) {
      process.env[key] = value;
    }
  }
}

function required(env: NodeJS.ProcessEnv, key: string): string {
  const value = env[key];
  if (value === undefined || value.trim() === "") {
    throw new ConfigError(`Missing required environment variable ${key}. See .env.example.`);
  }
  return value.trim();
}

function optional(env: NodeJS.ProcessEnv, key: string): string | undefined {
  const value = env[key];
  if (value === undefined || value.trim() === "") {
    return undefined;
  }
  return value.trim();
}

function intOr(env: NodeJS.ProcessEnv, key: string, fallback: number): number {
  const raw = optional(env, key);
  if (raw === undefined) {
    return fallback;
  }
  const parsed = Number.parseInt(raw, 10);
  if (Number.isNaN(parsed) || parsed < 0) {
    throw new ConfigError(`${key} must be a non-negative integer.`);
  }
  return parsed;
}

function splitList(raw: string | undefined): string[] {
  if (raw === undefined) {
    return [];
  }
  return raw.split(",").map((s) => s.trim()).filter((s) => s !== "");
}

function parseJson<T>(raw: string, key: string): T {
  try {
    return JSON.parse(raw) as T;
  } catch {
    throw new ConfigError(`${key} is not valid JSON.`);
  }
}

/** Shape accepted inside FAMILIES_JSON. */
interface FamilyInput {
  id?: unknown;
  childName?: unknown;
  grade?: unknown;
  username?: unknown;
  password?: unknown;
  telegramChatIds?: unknown;
  calendarId?: unknown;
}

function asNonEmptyString(value: unknown, label: string): string {
  if (typeof value !== "string" || value.trim() === "") {
    throw new ConfigError(`FAMILIES_JSON: ${label} must be a non-empty string.`);
  }
  return value.trim();
}

function toFamily(input: FamilyInput, index: number): Family {
  const label = `families[${index}]`;
  const chatIds = input.telegramChatIds;
  if (!Array.isArray(chatIds) || chatIds.length === 0) {
    throw new ConfigError(`FAMILIES_JSON: ${label}.telegramChatIds must be a non-empty array.`);
  }
  const base = {
    id: asNonEmptyString(input.id, `${label}.id`),
    childName: asNonEmptyString(input.childName, `${label}.childName`),
    grade: asNonEmptyString(input.grade, `${label}.grade`),
    schoolDiary: {
      username: asNonEmptyString(input.username, `${label}.username`),
      password: asNonEmptyString(input.password, `${label}.password`),
    },
    telegramChatIds: chatIds.map((c, i) => asNonEmptyString(String(c), `${label}.telegramChatIds[${i}]`)),
  };
  if (typeof input.calendarId === "string" && input.calendarId.trim() !== "") {
    return { ...base, calendarId: input.calendarId.trim() };
  }
  return base;
}

function loadFamilies(env: NodeJS.ProcessEnv): Family[] {
  const multi = optional(env, "FAMILIES_JSON");
  if (multi !== undefined) {
    const parsed = parseJson<unknown>(multi, "FAMILIES_JSON");
    if (!Array.isArray(parsed) || parsed.length === 0) {
      throw new ConfigError("FAMILIES_JSON must be a non-empty JSON array.");
    }
    const families = parsed.map((f, i) => toFamily(f as FamilyInput, i));
    const ids = new Set(families.map((f) => f.id));
    if (ids.size !== families.length) {
      throw new ConfigError("FAMILIES_JSON: every family id must be unique.");
    }
    return families;
  }
  const chatIds = splitList(required(env, "TELEGRAM_CHAT_IDS"));
  if (chatIds.length === 0) {
    throw new ConfigError("TELEGRAM_CHAT_IDS must contain at least one chat id.");
  }
  const base = {
    id: optional(env, "FAMILY_ID") ?? "default",
    childName: required(env, "CHILD_NAME"),
    grade: required(env, "CHILD_GRADE"),
    schoolDiary: {
      username: required(env, "SD_USERNAME"),
      password: required(env, "SD_PASSWORD"),
    },
    telegramChatIds: chatIds,
  };
  const calendarId = optional(env, "GOOGLE_CALENDAR_ID");
  if (calendarId !== undefined) {
    return [{ ...base, calendarId }];
  }
  return [base];
}

function loadPortal(env: NodeJS.ProcessEnv): PortalConfig {
  const patternRaw = optional(env, "SD_FEED_API_PATTERN") ?? "(feed|post|message|homework|notice|event|circular|diary)";
  let feedApiPattern: RegExp;
  try {
    feedApiPattern = new RegExp(patternRaw, "i");
  } catch {
    throw new ConfigError("SD_FEED_API_PATTERN is not a valid regular expression.");
  }
  const fieldMapRaw = optional(env, "SD_FIELD_MAP");
  let fieldMap: PortalConfig["fieldMap"] = {};
  if (fieldMapRaw !== undefined) {
    fieldMap = parseJson<PortalConfig["fieldMap"]>(fieldMapRaw, "SD_FIELD_MAP");
  }
  return {
    loginUrl: required(env, "SD_LOGIN_URL"),
    usernameSelector: optional(env, "SD_USERNAME_SELECTOR") ?? "input[type='text'], input[type='email'], input[name*='user' i]",
    passwordSelector: optional(env, "SD_PASSWORD_SELECTOR") ?? "input[type='password']",
    submitSelector: optional(env, "SD_SUBMIT_SELECTOR") ?? "button[type='submit'], input[type='submit']",
    feedPageUrls: splitList(optional(env, "SD_FEED_PAGE_URLS")),
    feedApiPattern,
    fieldMap,
    headless: optional(env, "HEADLESS") !== "false",
    executablePath: optional(env, "CHROMIUM_EXECUTABLE_PATH"),
  };
}

/**
 * Builds the full application config.
 * @param env - Environment to read from (injectable for tests).
 * @param needs - Which integrations the current command needs; others are not validated.
 */
export function loadConfig(
  env: NodeJS.ProcessEnv = process.env,
  needs: { readonly ai: boolean; readonly telegram: boolean } = { ai: true, telegram: true },
): AppConfig {
  const aiKey = optional(env, "ANTHROPIC_API_KEY");
  if (needs.ai && aiKey === undefined) {
    throw new ConfigError("Missing required environment variable ANTHROPIC_API_KEY. See .env.example.");
  }
  const botToken = optional(env, "TELEGRAM_BOT_TOKEN");
  if (needs.telegram && botToken === undefined) {
    throw new ConfigError("Missing required environment variable TELEGRAM_BOT_TOKEN. See .env.example.");
  }
  return {
    anthropicApiKey: aiKey ?? "",
    claudeModel: optional(env, "CLAUDE_MODEL") ?? "claude-haiku-5-5",
    telegramBotToken: botToken ?? "",
    telegramApiBase: optional(env, "TELEGRAM_API_BASE") ?? "https://api.telegram.org",
    googleServiceAccountJson: optional(env, "GOOGLE_SERVICE_ACCOUNT_JSON"),
    stateFile: optional(env, "STATE_FILE") ?? "data/state.json",
    firstRunLookbackDays: intOr(env, "FIRST_RUN_LOOKBACK_DAYS", 3),
    maxAttachmentBytes: intOr(env, "MAX_ATTACHMENT_BYTES", 8 * 1024 * 1024),
    questionsPerSubject: intOr(env, "QUESTIONS_PER_SUBJECT", 3),
    portal: loadPortal(env),
    families: loadFamilies(env),
  };
}
