/**
 * @file calendar.ts
 * @description Creates Google Calendar events (with phone reminders) for events, exams,
 *              holidays, fee deadlines and anything that needs a parent action on a date.
 *              Uses a service account; share your calendar with its email ("Make changes
 *              to events"). Event IDs are deterministic, so re-runs never create duplicates.
 */

import { createHash } from "node:crypto";
import { JWT } from "google-auth-library";
import type { ExtractedItem, ItemKind } from "../types.js";
import { addDays, isIsoDate, isTime, SCHOOL_TIME_ZONE } from "../util/dates.js";

const CALENDAR_SCOPE = "https://www.googleapis.com/auth/calendar.events";

/** Which date (if any) puts an item on the calendar, per kind. Homework stays in Telegram only. */
const CALENDAR_DATE_BY_KIND: Readonly<Record<ItemKind, (item: ExtractedItem) => string | null>> = {
  event: (i) => i.eventDate,
  exam: (i) => i.eventDate ?? i.dueDate,
  holiday: (i) => i.eventDate,
  fee: (i) => i.dueDate,
  notice: (i) => withParentAction(i, i.eventDate ?? i.dueDate),
  homework: (i) => withItemsOrAction(i, i.dueDate),
  classwork: () => null,
  other: (i) => withParentAction(i, i.eventDate ?? i.dueDate),
};

function withParentAction(item: ExtractedItem, date: string | null): string | null {
  if (item.parentAction === null) {
    return null;
  }
  return date;
}

/** Homework only goes on the calendar when something must be bought/sent or the parent must act. */
function withItemsOrAction(item: ExtractedItem, date: string | null): string | null {
  if (item.itemsNeeded.length === 0 && item.parentAction === null) {
    return null;
  }
  return date;
}

/** Calendar date for the item, or null if it should not be on the calendar. */
export function calendarDateFor(item: ExtractedItem): string | null {
  const date = CALENDAR_DATE_BY_KIND[item.kind](item);
  if (!isIsoDate(date)) {
    return null;
  }
  return date;
}

/** Google event IDs allow base32hex (0-9, a-v); a hex digest fits. */
export function eventIdFor(familyId: string, postId: string): string {
  return createHash("sha1").update(`${familyId}:${postId}`).digest("hex");
}

interface CalendarEventBody {
  id: string;
  summary: string;
  description: string;
  location?: string;
  start: Record<string, string>;
  end: Record<string, string>;
  reminders: { useDefault: false; overrides: { method: "popup"; minutes: number }[] };
}

/** Builds the Google Calendar event body. Timed events get 1-day and 1-hour reminders; all-day events a 6 PM previous-day reminder. */
export function buildEvent(familyId: string, childName: string, item: ExtractedItem, date: string): CalendarEventBody {
  const details = [
    item.summary,
    item.dressCode && `Dress: ${item.dressCode}`,
    item.itemsNeeded.length > 0 && `Send/carry: ${item.itemsNeeded.join(", ")}`,
    item.parentAction && `Parent: ${item.parentAction}`,
    "Source: SchoolDiary",
  ].filter((line): line is string => typeof line === "string" && line !== "");
  const label = item.subject ?? item.kind;
  const base = {
    id: eventIdFor(familyId, item.postId),
    summary: `${childName}: ${label} - ${item.summary}`.slice(0, 200),
    description: details.join("\n"),
  };
  const withLocation: Omit<CalendarEventBody, "start" | "end" | "reminders"> = { ...base };
  if (item.location !== null) {
    withLocation.location = item.location;
  }
  if (isTime(item.eventTime)) {
    const start = `${date}T${item.eventTime}:00`;
    const endHour = String(Math.min(Number(item.eventTime.slice(0, 2)) + 1, 23)).padStart(2, "0");
    const end = `${date}T${endHour}:${item.eventTime.slice(3)}:00`;
    return {
      ...withLocation,
      start: { dateTime: start, timeZone: SCHOOL_TIME_ZONE },
      end: { dateTime: end, timeZone: SCHOOL_TIME_ZONE },
      reminders: { useDefault: false, overrides: [{ method: "popup", minutes: 1_440 }, { method: "popup", minutes: 60 }] },
    };
  }
  return {
    ...withLocation,
    start: { date },
    end: { date: addDays(date, 1) },
    reminders: { useDefault: false, overrides: [{ method: "popup", minutes: 360 }] },
  };
}

export class CalendarClient {
  private readonly jwt: JWT;

  constructor(serviceAccountJson: string) {
    const creds = JSON.parse(serviceAccountJson) as { client_email?: string; private_key?: string };
    if (creds.client_email === undefined || creds.private_key === undefined) {
      throw new Error("GOOGLE_SERVICE_ACCOUNT_JSON must contain client_email and private_key.");
    }
    this.jwt = new JWT({ email: creds.client_email, key: creds.private_key, scopes: [CALENDAR_SCOPE] });
  }

  /**
   * Inserts the event; a 409 means it already exists and counts as success.
   * @returns The event id.
   */
  async upsert(calendarId: string, event: CalendarEventBody): Promise<string> {
    const url = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events`;
    const response = await this.jwt.request({
      url,
      method: "POST",
      data: event,
      validateStatus: (status: number) => status < 500,
    });
    if (response.status === 409) {
      return event.id;
    }
    if (response.status >= 400) {
      throw new Error(`Google Calendar insert failed with status ${response.status}`);
    }
    return event.id;
  }
}
