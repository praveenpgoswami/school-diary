/**
 * @file telegram.ts
 * @description Sends messages through the Telegram Bot API (free, no SDK needed).
 *              Long digests are split on line boundaries under Telegram's 4096-char limit.
 */

import { log } from "../util/log.js";

const TELEGRAM_LIMIT = 3_900;

function appendLine(current: string, line: string): string {
  if (current === "") {
    return line;
  }
  return `${current}\n${line}`;
}

/** Splits text into chunks below the limit, breaking on newlines where possible. */
export function chunkMessage(text: string, limit = TELEGRAM_LIMIT): string[] {
  const chunks: string[] = [];
  let current = "";
  for (const line of text.split("\n")) {
    const pieces: string[] = [];
    for (let i = 0; i < line.length; i += limit) {
      pieces.push(line.slice(i, i + limit));
    }
    if (pieces.length === 0) {
      pieces.push("");
    }
    for (const piece of pieces) {
      const candidate = appendLine(current, piece);
      if (candidate.length > limit && current !== "") {
        chunks.push(current);
        current = piece;
      } else {
        current = candidate;
      }
    }
  }
  if (current.trim() !== "") {
    chunks.push(current);
  }
  return chunks;
}

export class TelegramClient {
  constructor(
    private readonly botToken: string,
    private readonly apiBase = "https://api.telegram.org",
  ) {}

  private async call(method: string, payload: Record<string, unknown>): Promise<unknown> {
    const response = await fetch(`${this.apiBase}/bot${this.botToken}/${method}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    const json = (await response.json()) as { ok: boolean; description?: string; result?: unknown };
    if (!json.ok) {
      throw new Error(`Telegram ${method} failed: ${json.description ?? response.status}`);
    }
    return json.result;
  }

  /** Sends an HTML-formatted message to one chat, chunked if needed. Caller must escape user text. */
  async send(chatId: string, html: string): Promise<void> {
    for (const chunk of chunkMessage(html)) {
      await this.call("sendMessage", { chat_id: chatId, text: chunk, parse_mode: "HTML", disable_web_page_preview: true });
    }
  }

  /** Sends to every chat; a failure for one chat is logged and does not block the others. */
  async broadcast(chatIds: readonly string[], html: string): Promise<number> {
    let delivered = 0;
    for (const chatId of chatIds) {
      try {
        await this.send(chatId, html);
        delivered += 1;
      } catch (err) {
        log.error("Telegram delivery failed", { chatId, error: (err as Error).message });
      }
    }
    return delivered;
  }

  /** Lists chats that recently messaged the bot, so you can find your chat id during setup. */
  async recentChats(): Promise<{ id: string; name: string }[]> {
    const updates = (await this.call("getUpdates", { timeout: 0 })) as { message?: { chat?: { id: number; first_name?: string; title?: string } } }[];
    const chats = new Map<string, string>();
    for (const u of updates) {
      const chat = u.message?.chat;
      if (chat !== undefined) {
        chats.set(String(chat.id), chat.title ?? chat.first_name ?? "");
      }
    }
    return [...chats.entries()].map(([id, name]) => ({ id, name }));
  }
}
