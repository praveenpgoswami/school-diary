/**
 * @file log.ts
 * @description Tiny structured logger that redacts registered secrets before printing.
 *              Register every password/token at startup so it can never leak into
 *              GitHub Actions logs, even inside an error message.
 */

const secrets = new Set<string>();

/** Registers a value that must never appear in logs. Ignores short strings to avoid over-redaction. */
export function registerSecret(value: string | undefined): void {
  if (value !== undefined && value.length >= 4) {
    secrets.add(value);
  }
}

/** Replaces every registered secret in the text with "***". */
export function redact(text: string): string {
  let out = text;
  for (const s of secrets) {
    out = out.split(s).join("***");
  }
  return out;
}

type Level = "info" | "warn" | "error";

const writers: Record<Level, (line: string) => void> = {
  info: (line) => console.log(line),
  warn: (line) => console.warn(line),
  error: (line) => console.error(line),
};

function emit(level: Level, message: string, meta?: Record<string, unknown>): void {
  const payload = { ts: new Date().toISOString(), level, message, ...meta };
  writers[level](redact(JSON.stringify(payload)));
}

export const log = {
  info: (message: string, meta?: Record<string, unknown>): void => emit("info", message, meta),
  warn: (message: string, meta?: Record<string, unknown>): void => emit("warn", message, meta),
  error: (message: string, meta?: Record<string, unknown>): void => emit("error", message, meta),
};

/** Converts an unknown thrown value to a printable string. */
export function errorMessage(err: unknown): string {
  if (err instanceof Error) {
    return err.message;
  }
  return String(err);
}
