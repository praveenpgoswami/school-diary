/**
 * @file html.ts
 * @description Escaping for Telegram's HTML parse mode. Telegram rejects the whole
 *              message if a stray "<" or "&" appears, and school notices contain both.
 */

const ENTITIES: Record<string, string> = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
};

/** Escapes text for safe use inside Telegram HTML messages. */
export function escapeHtml(text: string): string {
  return text.replace(/[&<>"]/g, (ch) => ENTITIES[ch] ?? ch);
}
