/**
 * @file practiceQuestions.ts
 * @description Generates short, class-appropriate practice questions from the day's
 *              homework and classwork topics. Questions stay strictly on topics the
 *              school actually posted, so revision matches what was taught.
 */

import type { ExtractedItem, PracticeQuestion } from "../types.js";
import type { ClaudeClient, ToolSpec } from "./claudeClient.js";

const QUESTION_KINDS: ReadonlySet<ExtractedItem["kind"]> = new Set(["homework", "classwork", "exam"]);

export const QUESTIONS_TOOL: ToolSpec = {
  name: "record_practice_questions",
  description: "Record practice questions with short answers for the parent.",
  inputSchema: {
    type: "object",
    properties: {
      questions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            subject: { type: "string" },
            question: { type: "string", description: "Question to read to the child." },
            answer: { type: "string", description: "Short correct answer for the parent." },
          },
          required: ["subject", "question", "answer"],
        },
      },
    },
    required: ["questions"],
  },
};

const SYSTEM_PROMPT = [
  "You write revision questions a parent can ask their child at home.",
  "- Only use the topics given. Do not add new topics.",
  "- Match the child's class level: short sentences, simple words, no trick questions.",
  "- Mix formats: fill in the blank, one-word answer, true/false, small sums, \"give two examples\".",
  "- Keep each answer short so the parent can check quickly.",
].join("\n");

/** Picks the items that should produce questions: homework/classwork/exam posts that list topics. */
export function questionSources(items: readonly ExtractedItem[]): ExtractedItem[] {
  return items.filter((i) => QUESTION_KINDS.has(i.kind) && i.topics.length > 0);
}

/** Validates the model's questions; drops malformed entries and caps the total. */
export function validateQuestions(raw: unknown, maxTotal: number): PracticeQuestion[] {
  if (typeof raw !== "object" || raw === null) {
    return [];
  }
  const list = (raw as { questions?: unknown }).questions;
  if (!Array.isArray(list)) {
    return [];
  }
  const valid: PracticeQuestion[] = [];
  for (const entry of list) {
    if (typeof entry !== "object" || entry === null) {
      continue;
    }
    const { subject, question, answer } = entry as Record<string, unknown>;
    if (typeof subject === "string" && typeof question === "string" && typeof answer === "string" && question.trim() !== "") {
      valid.push({ subject: subject.trim().slice(0, 40), question: question.trim().slice(0, 300), answer: answer.trim().slice(0, 200) });
    }
  }
  return valid.slice(0, maxTotal);
}

/**
 * Generates practice questions for the given items.
 * @returns An empty array when no item has usable topics (no API call is made).
 */
export async function generateQuestions(
  claude: ClaudeClient,
  items: readonly ExtractedItem[],
  grade: string,
  perSubject: number,
): Promise<PracticeQuestion[]> {
  const sources = questionSources(items);
  if (sources.length === 0 || perSubject === 0) {
    return [];
  }
  const bySubject = new Map<string, Set<string>>();
  for (const item of sources) {
    const subject = item.subject ?? "General";
    const topics = bySubject.get(subject) ?? new Set<string>();
    item.topics.forEach((t) => topics.add(t));
    bySubject.set(subject, topics);
  }
  const topicLines = [...bySubject.entries()].map(([subject, topics]) => `- ${subject}: ${[...topics].join("; ")}`);
  const raw = await claude.callTool({
    system: SYSTEM_PROMPT,
    content: [{
      type: "text",
      text: [
        `Child's class: ${grade}`,
        `Write ${perSubject} questions per subject on these topics:`,
        ...topicLines,
      ].join("\n"),
    }],
    tool: QUESTIONS_TOOL,
    maxTokens: 2_048,
  });
  return validateQuestions(raw, perSubject * bySubject.size);
}
