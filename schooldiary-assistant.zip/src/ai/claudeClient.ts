/**
 * @file claudeClient.ts
 * @description Thin wrapper over the Anthropic SDK that forces a single tool call and
 *              returns that tool's input. Forcing a tool (tool_choice) is how we get
 *              reliably structured JSON back instead of free text.
 */

import Anthropic from "@anthropic-ai/sdk";

export type ContentBlock = Anthropic.ContentBlockParam;

export interface ToolSpec {
  readonly name: string;
  readonly description: string;
  readonly inputSchema: Anthropic.Tool.InputSchema;
}

export class ClaudeClient {
  private readonly client: Anthropic;

  constructor(apiKey: string, private readonly model: string) {
    this.client = new Anthropic({ apiKey, maxRetries: 3, timeout: 120_000 });
  }

  /**
   * Sends one user turn and returns the forced tool's input object.
   * @throws Error if the model does not return the tool call.
   */
  async callTool(params: {
    readonly system: string;
    readonly content: readonly ContentBlock[];
    readonly tool: ToolSpec;
    readonly maxTokens: number;
  }): Promise<unknown> {
    const response = await this.client.messages.create({
      model: this.model,
      max_tokens: params.maxTokens,
      system: params.system,
      tools: [{ name: params.tool.name, description: params.tool.description, input_schema: params.tool.inputSchema }],
      tool_choice: { type: "tool", name: params.tool.name },
      messages: [{ role: "user", content: [...params.content] }],
    });
    const toolUse = response.content.find(
      (block): block is Anthropic.ToolUseBlock => block.type === "tool_use" && block.name === params.tool.name,
    );
    if (toolUse === undefined) {
      throw new Error(`Claude did not return the ${params.tool.name} tool call (stop_reason: ${response.stop_reason}).`);
    }
    return toolUse.input;
  }
}
