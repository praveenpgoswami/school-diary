/**
 * @file buildDigest.ts
 * @description Pure functions that turn extracted items into the two Telegram messages:
 *              the evening digest (what's new, what's due tomorrow, what to pack, what's
 *              coming up, practice questions) and the morning checklist. No I/O, fully tested.
 */

import type { ExtractedItem, ItemKind, PracticeQuestion } from "../types.js";
import { addDays, daysBetween, isIsoDate, prettyDate } from "../util/dates.js";
import { escapeHtml } from "../util/html.js";

const KIND_LABEL: Readonly<Record<ItemKind, string>> = {
  homework: "📝 Homework",
  classwork: "📖 Classwork",
  event: "🎉 Event",
  notice: "📢 Notice",
  fee: "💰 Fee",
  exam: "🧪 Exam/Test",
  holiday: "🏖️ Holiday",
  other: "📌 Other",
};

const KIND_ORDER: readonly ItemKind[] = ["exam", "event", "fee", "homework", "classwork", "holiday", "notice", "other"];
const UPCOMING_WINDOW_DAYS = 14;

function e(text: string): string {
  return escapeHtml(text);
}

function subjectPrefix(item: ExtractedItem): string {
  if (item.subject === null) {
    return "";
  }
  return `<b>${e(item.subject)}:</b> `;
}

function timeSuffix(item: ExtractedItem): string {
  if (item.eventTime === null) {
    return "";
  }
  return ` at ${item.eventTime}`;
}

function byDateSuffix(date: string | null): string {
  if (date === null) {
    return "";
  }
  return ` (by ${prettyDate(date)})`;
}

/** Date that makes the item "happen": event date first, then due date. */
export function keyDate(item: ExtractedItem): string | null {
  if (isIsoDate(item.eventDate)) {
    return item.eventDate;
  }
  if (isIsoDate(item.dueDate)) {
    return item.dueDate;
  }
  return null;
}

function section(title: string, lines: readonly string[]): string[] {
  if (lines.length === 0) {
    return [];
  }
  return ["", `<b>${title}</b>`, ...lines];
}

function unique(values: readonly string[]): string[] {
  const seen = new Map<string, string>();
  for (const v of values) {
    const key = v.trim().toLowerCase();
    if (key !== "" && !seen.has(key)) {
      seen.set(key, v.trim());
    }
  }
  return [...seen.values()];
}

function happensOn(item: ExtractedItem, date: string): boolean {
  return item.dueDate === date || item.eventDate === date;
}

function packList(items: readonly ExtractedItem[], date: string): string[] {
  const needed = items.filter((i) => happensOn(i, date)).flatMap((i) => i.itemsNeeded);
  const dress = items.filter((i) => happensOn(i, date) && i.dressCode !== null).map((i) => `Dress: ${i.dressCode ?? ""}`);
  return unique([...dress, ...needed]).map((v) => `• ${e(v)}`);
}

function byKindThenDate(a: ExtractedItem, b: ExtractedItem): number {
  const kindDiff = KIND_ORDER.indexOf(a.kind) - KIND_ORDER.indexOf(b.kind);
  if (kindDiff !== 0) {
    return kindDiff;
  }
  return (keyDate(a) ?? "9999").localeCompare(keyDate(b) ?? "9999");
}

function questionLines(questions: readonly PracticeQuestion[]): string[] {
  return questions.map((q, i) => `${i + 1}. <i>${e(q.subject)}</i> ${e(q.question)}\n   Answer: <tg-spoiler>${e(q.answer)}</tg-spoiler>`);
}

/**
 * Evening digest.
 * @param newItems - Items extracted from posts first seen in this run.
 * @param allItems - Every stored item (including new ones), for due/upcoming sections.
 * @param today - IST date, YYYY-MM-DD.
 */
export function buildEveningDigest(params: {
  readonly childName: string;
  readonly today: string;
  readonly newItems: readonly ExtractedItem[];
  readonly allItems: readonly ExtractedItem[];
  readonly questions: readonly PracticeQuestion[];
}): string {
  const { childName, today, newItems, allItems, questions } = params;
  const tomorrow = addDays(today, 1);

  const newLines = [...newItems].sort(byKindThenDate).map((i) => `${KIND_LABEL[i.kind]} · ${subjectPrefix(i)}${e(i.summary)}`);

  const dueTomorrow = allItems
    .filter((i) => happensOn(i, tomorrow))
    .sort(byKindThenDate)
    .map((i) => `• ${KIND_LABEL[i.kind]} · ${subjectPrefix(i)}${e(i.summary)}${timeSuffix(i)}`);

  const parentTodo = allItems
    .filter((i) => i.parentAction !== null)
    .filter((i) => {
      const d = keyDate(i);
      if (d === null) {
        return newItems.some((n) => n.postId === i.postId);
      }
      const gap = daysBetween(today, d);
      return gap >= 0 && gap <= 7;
    })
    .map((i) => `• ${e(i.parentAction ?? "")}${byDateSuffix(keyDate(i))}`);

  const upcoming = allItems
    .filter((i) => {
      const d = keyDate(i);
      if (d === null) {
        return false;
      }
      const gap = daysBetween(today, d);
      return gap > 1 && gap <= UPCOMING_WINDOW_DAYS && i.kind !== "classwork";
    })
    .sort((a, b) => (keyDate(a) ?? "").localeCompare(keyDate(b) ?? ""))
    .map((i) => `• <b>${prettyDate(keyDate(i) ?? today)}</b> · ${KIND_LABEL[i.kind]} · ${e(i.summary)}${timeSuffix(i)}`);

  const lines = [
    `<b>📚 ${e(childName)} · School update · ${prettyDate(today)}</b>`,
    ...section("🆕 New today", newLines),
    ...section(`⏰ For tomorrow (${prettyDate(tomorrow)})`, dueTomorrow),
    ...section("🎒 Pack / send tomorrow", packList(allItems, tomorrow)),
    ...section("✅ You need to", parentTodo),
    ...section("📅 Coming up", upcoming),
    ...section("🧠 Practice questions (tap to reveal answers)", questionLines(questions)),
  ];
  if (newLines.length === 0 && dueTomorrow.length === 0 && upcoming.length === 0) {
    lines.push("", "No new posts and nothing due tomorrow. 🎈");
  }
  return lines.join("\n");
}

/** Morning checklist for today. */
export function buildMorningChecklist(params: {
  readonly childName: string;
  readonly today: string;
  readonly allItems: readonly ExtractedItem[];
}): string {
  const { childName, today, allItems } = params;
  const todays = allItems.filter((i) => happensOn(i, today)).sort(byKindThenDate);
  const lines = [
    `<b>☀️ ${e(childName)} · Today, ${prettyDate(today)}</b>`,
    ...section("Today", todays.map((i) => `• ${KIND_LABEL[i.kind]} · ${subjectPrefix(i)}${e(i.summary)}${timeSuffix(i)}`)),
    ...section("🎒 Bag check", packList(allItems, today)),
    ...section("✅ You need to", todays.filter((i) => i.parentAction !== null).map((i) => `• ${e(i.parentAction ?? "")}`)),
  ];
  if (todays.length === 0) {
    lines.push("", "Nothing special today. Regular bag and uniform. 👍");
  }
  return lines.join("\n");
}
