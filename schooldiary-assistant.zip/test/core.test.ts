/**
 * @file core.test.ts
 * @description Tests for dates, extraction validation, question validation, calendar
 *              event building, Telegram chunking, state merging, post selection and digests.
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import type { ExtractedItem, RawPost } from "../src/types.js";
import { addDays, daysBetween, isIsoDate, istDate, prettyDate } from "../src/util/dates.js";
import { validateItem, buildExtractionContent } from "../src/ai/extract.js";
import { validateQuestions, questionSources } from "../src/ai/practiceQuestions.js";
import { buildEvent, calendarDateFor, eventIdFor } from "../src/delivery/calendar.js";
import { chunkMessage } from "../src/delivery/telegram.js";
import { mergeFamilyState } from "../src/store/stateStore.js";
import { selectNewPosts } from "../src/jobs/evening.js";
import { buildEveningDigest, buildMorningChecklist } from "../src/digest/buildDigest.js";
import { escapeHtml } from "../src/util/html.js";
import { redact, registerSecret } from "../src/util/log.js";
import { resolveMediaType } from "../src/sources/schoolDiarySource.js";

const POST: RawPost = { id: "p1", title: "Annual day", body: "Annual day on 24 Oct at 9:30.", postedAt: "2026-10-13T05:00:00Z", attachments: [] };

function item(overrides: Partial<ExtractedItem>): ExtractedItem {
  return {
    postId: "x", kind: "notice", subject: null, summary: "s", dueDate: null, eventDate: null, eventTime: null,
    location: null, dressCode: null, itemsNeeded: [], parentAction: null, topics: [], postedAt: "2026-10-13T05:00:00Z",
    ...overrides,
  };
}

test("IST date rolls over at IST midnight, not UTC midnight", () => {
  assert.equal(istDate(new Date("2026-10-13T18:29:00Z")), "2026-10-13");
  assert.equal(istDate(new Date("2026-10-13T18:31:00Z")), "2026-10-14");
});

test("date helpers", () => {
  assert.equal(addDays("2026-10-31", 1), "2026-11-01");
  assert.equal(daysBetween("2026-10-13", "2026-10-24"), 11);
  assert.equal(isIsoDate("2026-02-30"), false);
  assert.equal(isIsoDate("2026-10-24"), true);
  assert.equal(prettyDate("2026-10-14"), "Wed 14 Oct");
});

test("validateItem keeps valid fields and rejects bad ones", () => {
  const result = validateItem({
    kind: "event", subject: "  ", summary: "Annual day celebration", dueDate: "24/10/2026", eventDate: "2026-10-24",
    eventTime: "9:30", itemsNeeded: ["White dress", 5, ""], parentAction: "Attend", topics: "not-an-array",
  }, POST);
  assert.equal(result.kind, "event");
  assert.equal(result.subject, null);
  assert.equal(result.dueDate, null);
  assert.equal(result.eventDate, "2026-10-24");
  assert.equal(result.eventTime, null);
  assert.deepEqual(result.itemsNeeded, ["White dress"]);
  assert.deepEqual(result.topics, []);
  assert.equal(result.postId, "p1");
});

test("validateItem falls back safely on garbage", () => {
  const result = validateItem("nonsense", POST);
  assert.equal(result.kind, "other");
  assert.equal(result.summary, "Annual day");
});

test("extraction content puts attachments before text and wraps post as data", () => {
  const blocks = buildExtractionContent({ ...POST, attachments: [{ url: "u", fileName: "a.pdf", mediaType: "application/pdf", base64: "QQ==" }] }, "3");
  assert.equal(blocks[0]?.type, "document");
  assert.equal(blocks[1]?.type, "text");
  assert.match(String((blocks[1] as { text: string }).text), /<post>[\s\S]*<\/post>/);
});

test("question validation drops malformed entries and caps total", () => {
  const q = validateQuestions({ questions: [
    { subject: "Maths", question: "2+3?", answer: "5" },
    { subject: "Maths", question: "", answer: "x" },
    { subject: "EVS", question: "Name a root vegetable", answer: "Carrot" },
    "bad",
  ] }, 1);
  assert.deepEqual(q, [{ subject: "Maths", question: "2+3?", answer: "5" }]);
  assert.equal(questionSources([item({ kind: "homework", topics: ["Plants"] }), item({ kind: "event", topics: ["x"] })]).length, 1);
});

test("calendar date selection by kind", () => {
  assert.equal(calendarDateFor(item({ kind: "event", eventDate: "2026-10-24" })), "2026-10-24");
  assert.equal(calendarDateFor(item({ kind: "homework", dueDate: "2026-10-14" })), null);
  assert.equal(calendarDateFor(item({ kind: "homework", dueDate: "2026-10-14", itemsNeeded: ["Chart paper"] })), "2026-10-14");
  assert.equal(calendarDateFor(item({ kind: "notice", eventDate: "2026-10-20" })), null);
  assert.equal(calendarDateFor(item({ kind: "notice", eventDate: "2026-10-20", parentAction: "Sign slip" })), "2026-10-20");
  assert.equal(calendarDateFor(item({ kind: "fee", dueDate: "bad" })), null);
});

test("calendar events: deterministic id, timed vs all-day reminders", () => {
  assert.equal(eventIdFor("f", "p1"), eventIdFor("f", "p1"));
  assert.match(eventIdFor("f", "p1"), /^[0-9a-v]{5,1024}$/);
  const timed = buildEvent("f", "Anya", item({ kind: "event", eventDate: "2026-10-24", eventTime: "09:30", location: "Hall" }), "2026-10-24");
  assert.equal(timed.start["dateTime"], "2026-10-24T09:30:00");
  assert.equal(timed.end["dateTime"], "2026-10-24T10:30:00");
  assert.equal(timed.location, "Hall");
  const allDay = buildEvent("f", "Anya", item({ kind: "holiday", eventDate: "2026-10-31" }), "2026-10-31");
  assert.equal(allDay.start["date"], "2026-10-31");
  assert.equal(allDay.end["date"], "2026-11-01");
  assert.equal(allDay.location, undefined);
  assert.deepEqual(allDay.reminders.overrides, [{ method: "popup", minutes: 360 }]);
});

test("telegram chunking respects the limit and keeps all text", () => {
  const text = Array.from({ length: 50 }, (_, i) => `line ${i} ${"x".repeat(40)}`).join("\n");
  const chunks = chunkMessage(text, 300);
  assert.ok(chunks.every((c) => c.length <= 300));
  assert.equal(chunks.join("\n"), text);
  assert.ok(chunkMessage("y".repeat(700), 300).every((c) => c.length <= 300));
});

test("first run skips old posts but marks them seen; later runs process all unseen", () => {
  const posts: RawPost[] = [
    { ...POST, id: "new", postedAt: "2026-10-12T05:00:00Z" },
    { ...POST, id: "old", postedAt: "2026-09-01T05:00:00Z" },
    { ...POST, id: "seen", postedAt: "2026-10-12T05:00:00Z" },
  ];
  const first = selectNewPosts(posts, { seenPostIds: ["seen"], items: [], calendarEventIds: [], lastRunAt: null }, "2026-10-13", 3);
  assert.deepEqual(first.toProcess.map((p) => p.id), ["new"]);
  assert.deepEqual(first.skippedAsOld, ["old"]);
  const later = selectNewPosts(posts, { seenPostIds: ["seen"], items: [], calendarEventIds: [], lastRunAt: "x" }, "2026-10-13", 3);
  assert.deepEqual(later.toProcess.map((p) => p.id), ["new", "old"]);
});

test("state merge replaces re-processed items and prunes stale ones", () => {
  const merged = mergeFamilyState(
    { seenPostIds: ["a"], items: [item({ postId: "a", summary: "v1" }), item({ postId: "stale", dueDate: "2026-07-01", postedAt: "2026-06-25T00:00:00Z" })], calendarEventIds: [], lastRunAt: null },
    { newPostIds: ["a", "b"], newItems: [item({ postId: "a", summary: "v2" })], newCalendarEventIds: ["e1"], today: "2026-10-13", runAt: "now" },
  );
  assert.deepEqual(merged.seenPostIds, ["a", "b"]);
  assert.deepEqual(merged.items.map((i) => i.summary), ["v2"]);
  assert.deepEqual(merged.calendarEventIds, ["e1"]);
  assert.equal(merged.lastRunAt, "now");
});

test("evening digest sections", () => {
  const items = [
    item({ postId: "1", kind: "homework", subject: "EVS", summary: "Draw & label a plant", dueDate: "2026-10-14", itemsNeeded: ["Chart paper"], topics: ["Plants"] }),
    item({ postId: "2", kind: "event", summary: "Annual day", eventDate: "2026-10-24", eventTime: "09:30", dressCode: "White", parentAction: "Attend" }),
    item({ postId: "3", kind: "fee", summary: "Term 2 fee", dueDate: "2026-10-18", parentAction: "Pay fee" }),
  ];
  const digest = buildEveningDigest({ childName: "Anya", today: "2026-10-13", newItems: items, allItems: items, questions: [{ subject: "EVS", question: "Name 2 parts of a plant", answer: "Root, stem" }] });
  assert.match(digest, /For tomorrow \(Wed 14 Oct\)/);
  assert.match(digest, /Draw &amp; label a plant/);
  assert.match(digest, /• Chart paper/);
  assert.match(digest, /Pay fee \(by Sun 18 Oct\)/);
  assert.doesNotMatch(digest, /Attend/);
  assert.match(digest, /Sat 24 Oct<\/b> · 🎉 Event · Annual day at 09:30/);
  assert.match(digest, /<tg-spoiler>Root, stem<\/tg-spoiler>/);
});

test("empty digest and morning checklist", () => {
  assert.match(buildEveningDigest({ childName: "A", today: "2026-10-13", newItems: [], allItems: [], questions: [] }), /No new posts/);
  const items = [item({ kind: "event", summary: "Sports day", eventDate: "2026-10-14", dressCode: "House T-shirt", itemsNeeded: ["Water bottle"], parentAction: "Drop at 7:30" })];
  const morning = buildMorningChecklist({ childName: "A", today: "2026-10-14", allItems: items });
  assert.match(morning, /Dress: House T-shirt/);
  assert.match(morning, /Water bottle/);
  assert.match(morning, /Drop at 7:30/);
  assert.match(buildMorningChecklist({ childName: "A", today: "2026-10-15", allItems: items }), /Nothing special today/);
});

test("html escaping, secret redaction, media type resolution", () => {
  assert.equal(escapeHtml(`<b>&"`), "&lt;b&gt;&amp;&quot;");
  registerSecret("hunter2pass");
  assert.equal(redact("login hunter2pass failed"), "login *** failed");
  assert.equal(resolveMediaType("application/pdf; charset=binary", "x"), "application/pdf");
  assert.equal(resolveMediaType("application/octet-stream", "photo.JPG?v=2"), "image/jpeg");
  assert.equal(resolveMediaType(undefined, "notes.docx"), undefined);
});
