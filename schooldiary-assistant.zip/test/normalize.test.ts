/**
 * @file normalize.test.ts
 * @description Tests that post detection works on varied, unknown JSON shapes and
 *              ignores look-alike objects (wrappers, authors, attachment records).
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import { normalizePosts, stripHtml, toIsoTimestamp } from "../src/sources/normalize.js";

const NOW = new Date("2026-10-13T12:00:00Z");

test("finds posts nested in an API wrapper and ignores the wrapper itself", () => {
  const body = {
    id: 99,
    message: "success",
    data: {
      feed: [
        { postId: "a1", subject: "EVS homework", description: "<p>Draw a plant.<br>Label parts.</p>", createdAt: "2026-10-12T10:00:00Z", author: { id: 7, name: "Ms Rao" } },
        { postId: "a2", subject: "Annual day", description: "Annual day on 24 Oct.", createdAt: 1760342400 },
      ],
    },
  };
  const posts = normalizePosts([body], {}, NOW);
  assert.deepEqual(posts.map((p) => p.id).sort(), ["a1", "a2"]);
  const evs = posts.find((p) => p.id === "a1");
  assert.equal(evs?.body, "Draw a plant.\nLabel parts.");
  assert.equal(evs?.title, "EVS homework");
});

test("extracts attachments from object arrays and from URLs in the body, without treating them as posts", () => {
  const body = [{
    id: "p1",
    title: "Worksheet",
    message: "See https://cdn.example.com/hw/ws-12.pdf?x=1",
    date: "2026-10-13",
    attachments: [{ id: 5, name: "Maths.png", url: "https://cdn.example.com/m.png" }],
  }];
  const posts = normalizePosts([body], {}, NOW);
  assert.equal(posts.length, 1);
  const urls = posts[0]?.attachments.map((a) => a.url);
  assert.deepEqual(urls, ["https://cdn.example.com/m.png", "https://cdn.example.com/hw/ws-12.pdf?x=1"]);
  assert.equal(posts[0]?.attachments[0]?.fileName, "Maths.png");
  assert.equal(posts[0]?.attachments[1]?.fileName, "ws-12.pdf");
});

test("deduplicates the same post across responses and sorts newest first", () => {
  const a = { items: [{ id: 1, body: "old", createdAt: "2026-10-01T00:00:00Z" }] };
  const b = { items: [{ id: 2, body: "new", createdAt: "2026-10-12T00:00:00Z" }, { id: 1, body: "old", createdAt: "2026-10-01T00:00:00Z" }] };
  const posts = normalizePosts([a, b], {}, NOW);
  assert.deepEqual(posts.map((p) => p.id), ["2", "1"]);
});

test("field map overrides find custom keys", () => {
  const body = { rows: [{ nid: "x9", hdr: "PTM", txt: "Parent teacher meeting Saturday", ts: "2026-10-10T05:00:00Z" }] };
  assert.equal(normalizePosts([body], {}, NOW).length, 0);
  const posts = normalizePosts([body], { id: ["nid"], title: ["hdr"], body: ["txt"], postedAt: ["ts"] }, NOW);
  assert.equal(posts[0]?.id, "x9");
  assert.equal(posts[0]?.title, "PTM");
});

test("rejects id+name objects with no body or date", () => {
  assert.equal(normalizePosts([{ users: [{ id: 1, name: "A" }, { id: 2, name: "B" }] }], {}, NOW).length, 0);
});

test("timestamp parsing handles seconds, milliseconds, strings and junk", () => {
  assert.equal(toIsoTimestamp(1760342400), "2025-10-13T08:00:00.000Z");
  assert.equal(toIsoTimestamp(1760342400000), "2025-10-13T08:00:00.000Z");
  assert.equal(toIsoTimestamp("1760342400"), "2025-10-13T08:00:00.000Z");
  assert.equal(toIsoTimestamp("2026-10-12T10:00:00Z"), "2026-10-12T10:00:00.000Z");
  assert.equal(toIsoTimestamp("not a date"), null);
});

test("stripHtml decodes entities and collapses whitespace", () => {
  assert.equal(stripHtml("Bring&nbsp;<b>chart</b> &amp; glue"), "Bring chart & glue");
});
