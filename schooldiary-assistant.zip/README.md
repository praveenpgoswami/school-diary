# SchoolDiary parent assistant

Checks your child's SchoolDiary every evening, reads each post and its PDF/photo attachments with Claude, and sends you on Telegram:

- **Evening digest (~7 PM):** what's new, what's due tomorrow, what to pack/send, what *you* must do, what's coming up in the next two weeks, and practice questions from the day's classwork (answers hidden behind a tap).
- **Morning checklist (~6:30 AM):** today's events, dress code, bag check and to-dos.
- **Google Calendar events (optional):** events, exams, holidays and fee deadlines with phone reminders. Re-runs never duplicate them.

If login fails or the portal changes, you get a Telegram alert instead of silence.

```
src/
  cli.ts                      evening | morning | discover | telegram-chats
  config.ts                   env loading + validation (single or multi-family)
  sources/schoolDiarySource.ts  Playwright login, JSON capture, attachment download
  sources/normalize.ts        finds posts in any JSON shape (unit-tested)
  ai/extract.ts               post → structured item (kind, dates, items, parent action)
  ai/practiceQuestions.ts     class-level questions from the day's topics
  digest/buildDigest.ts       evening digest + morning checklist (pure, tested)
  delivery/telegram.ts        Telegram Bot API
  delivery/calendar.ts        Google Calendar (service account)
  store/stateStore.ts         seen posts + items, committed back by Actions
  jobs/                       evening, morning, discover
.github/workflows/schooldiary.yml   free scheduler
```

## Setup (about 30 minutes, once)

### 1. Install and test

```bash
npm install
npx playwright install chromium
npm test            # 21 unit tests
cp .env.example .env
```

### 2. Telegram bot (free)

1. In Telegram, open **@BotFather** → `/newbot` → copy the token into `TELEGRAM_BOT_TOKEN`.
2. Send any message to your new bot (and have your wife do the same, or add the bot to a family group).
3. `npm run build && npm run telegram-chats`. Put the IDs it prints into `TELEGRAM_CHAT_IDS` (comma-separated).

### 3. Claude API key

Create a key at <https://console.anthropic.com> and set `ANTHROPIC_API_KEY`. This is the only paid part. Usage per day is small; set a monthly spend limit in the console. `CLAUDE_MODEL` defaults to Haiku (cheapest).

### 4. Connect to SchoolDiary (discovery)

The portal has no public API, so the assistant captures the JSON the portal's own pages load.

1. Set `SD_LOGIN_URL` (the parent web login page), `SD_USERNAME`, `SD_PASSWORD`.
2. Run with a visible browser:
   ```bash
   HEADLESS=false npm run discover
   ```
3. Open `data/discovery/summary.json`. Look for URLs with `postsDetected > 0`:
   - If posts are found and `matchedByPattern` is `true`, you're done.
   - If they're found but not matched, set `SD_FEED_API_PATTERN` to a regex matching that URL (e.g. `/api/v1/(feed|homework)`).
   - If homework/notices live on other pages, put those page URLs in `SD_FEED_PAGE_URLS` and run again.
   - If nothing is detected, open `responses.json`, find the post list, and set `SD_FIELD_MAP`, e.g. `{"id":["nid"],"title":["hdr"],"body":["txt"],"postedAt":["ts"]}`.
4. If the login form isn't found, set `SD_USERNAME_SELECTOR` / `SD_PASSWORD_SELECTOR` / `SD_SUBMIT_SELECTOR` (right-click the field → Inspect).

`data/discovery/` contains your child's data. It is git-ignored; remove names before sharing a sample.

### 5. First real run

```bash
npm run evening     # first run reads only the last 3 days (FIRST_RUN_LOOKBACK_DAYS)
npm run morning
```

### 6. Google Calendar (optional)

1. In Google Cloud Console: create a project → enable **Google Calendar API** → create a **service account** → **Keys → Add key → JSON**.
2. In Google Calendar → your calendar (or a new "School" calendar) → **Settings and sharing → Share with specific people** → add the service account email with **Make changes to events**.
3. Copy the **Calendar ID** from the same settings page into `GOOGLE_CALENDAR_ID`; paste the key JSON (one line) into `GOOGLE_SERVICE_ACCOUNT_JSON`.

### 7. Run it automatically on GitHub Actions (free)

1. Create a **private** repository and push this folder. Keep it private: `data/state.json` holds summaries of school posts.
2. **Settings → Secrets and variables → Actions**
   - *Secrets:* `ANTHROPIC_API_KEY`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_IDS`, `CHILD_NAME`, `CHILD_GRADE`, `SD_USERNAME`, `SD_PASSWORD`, and optionally `GOOGLE_SERVICE_ACCOUNT_JSON`, `GOOGLE_CALENDAR_ID`.
   - *Variables:* `SD_LOGIN_URL`, plus any of `SD_FEED_PAGE_URLS`, `SD_FEED_API_PATTERN`, `SD_FIELD_MAP`, selectors, `CLAUDE_MODEL` you set in step 4.
3. **Actions → SchoolDiary assistant → Run workflow** (mode `evening`) to test.

Schedules: 18:54 and 06:24 IST. GitHub may start scheduled runs some minutes late. Change the `cron` lines to move them (they're in UTC: IST − 5:30).

## Going multi-family

Set `FAMILIES_JSON` (see `.env.example`); each family gets its own login, chats, calendar and state, and one family failing doesn't affect others. Before offering this to other parents, see the product notes: storing other parents' passwords, SchoolDiary's terms, and India's DPDP Act all need to be addressed. A partnership with the platform or the school is the clean route.

## Security

- Passwords and tokens are only read from env/secrets and are redacted from every log line and alert.
- Post text is passed to Claude as data, with instructions to ignore any instructions inside it.
- Model output is validated field by field (dates, times, kinds, lengths) before use.
